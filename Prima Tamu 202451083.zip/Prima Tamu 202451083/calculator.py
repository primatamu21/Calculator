
import math
import tkinter as tk


def fmt(v):
    """Angka -> string internal (titik desimal)."""
    return str(int(v)) if v == int(v) and abs(v) < 1e16 else f"{v:.15g}"


def disp(s):
    """String internal -> tampilan (ribuan '.', desimal ',')."""
    if "e" in s:
        return s.replace(".", ",")
    sign, body = ("-" if s.startswith("-") else ""), s.lstrip("-")
    ip, dot, fp = body.partition(".")
    return sign + f"{int(ip):,}".replace(",", ".") + ("," + fp if dot else "")


def disp_expr(s):
    return " ".join(disp(t) if t.replace(".", "", 1).lstrip("-").isdigit() else t for t in s.split(" "))


class Engine:
    """Logika kalkulator (terpisah dari GUI)."""

    def __init__(self):
        self.mem = None
        self.reset()

    def reset(self):
        self.cur, self.acc, self.op, self.expr, self.tail = "0", None, None, "", ""
        self.new, self.just_op, self.after_eq, self.error = True, False, False, None

    val = property(lambda s: float(s.cur))
    top = property(lambda s: f"{s.expr} {s.tail}".strip())

    def _fail(self, msg):
        self.reset()
        self.error = msg

    def _ok(self):
        if self.error:
            self.reset()
        if self.after_eq:
            self.expr, self.after_eq = "", False

    @staticmethod
    def _calc(a, op, b):
        if op == "÷" and b == 0:
            raise ZeroDivisionError("Hasil tidak terdefinisi" if a == 0 else "Tidak dapat membagi dengan nol")
        r = {"+": a + b, "−": a - b, "×": a * b}.get(op) if op != "÷" else a / b
        if not math.isfinite(r):
            raise OverflowError("Melebihi batas")
        return r

    def digit(self, d):
        self._ok()
        self.tail = ""
        if self.new or self.cur == "0":
            self.cur = d
        elif len(self.cur.replace("-", "").replace(".", "")) < 16:
            self.cur += d
        self.new = self.just_op = False

    def decimal(self):
        self._ok()
        self.tail = ""
        if self.new:
            self.cur = "0."
        elif "." not in self.cur:
            self.cur += "."
        self.new = self.just_op = False

    def operator(self, o):
        if self.error:
            self.reset()
        if self.op and self.just_op:
            self.op, self.expr = o, self.expr[:-1] + o
            return
        operand = self.tail or fmt(self.val)
        if self.op:
            try:
                r = self._calc(self.acc, self.op, self.val)
            except (ZeroDivisionError, OverflowError) as e:
                return self._fail(str(e))
            self.acc, self.cur, self.expr = r, fmt(r), f"{self.expr} {operand} {o}"
        else:
            self.acc, self.expr = self.val, f"{operand} {o}"
        self.op, self.tail, self.new, self.just_op, self.after_eq = o, "", True, True, False

    def equals(self):
        if self.error:
            self.reset()
        operand = self.tail or fmt(self.val)
        if self.op is None:
            self.expr, self.tail, self.new, self.after_eq = f"{operand} =", "", True, True
            return
        try:
            r = self._calc(self.acc, self.op, self.val)
        except (ZeroDivisionError, OverflowError) as e:
            return self._fail(str(e))
        self.expr, self.tail, self.cur = f"{self.expr} {operand} =", "", fmt(r)
        self.acc = self.op = None
        self.new = self.after_eq = True
        self.just_op = False

    def ce(self):
        if self.error:
            return self.reset()
        self.cur, self.tail, self.new, self.just_op = "0", "", True, False
        if self.after_eq:
            self.expr, self.after_eq = "", False

    def back(self):
        if self.error:
            return self.reset()
        if self.new or self.tail:
            return
        self.cur = self.cur[:-1]
        if self.cur in ("", "-"):
            self.cur = "0"

    def negate(self):
        self._ok()
        if self.val:
            self.cur = self.cur[1:] if self.cur.startswith("-") else "-" + self.cur
            self.tail = ""

    def percent(self):
        self._ok()
        v = self.acc * self.val / 100 if (self.op and self.acc is not None) else 0.0
        self.cur = self.tail = fmt(v)
        self.new, self.just_op = True, False

    def unary(self, kind):
        self._ok()
        v, s = self.val, self.tail or fmt(self.val)
        if kind == "recip":
            if v == 0:
                return self._fail("Tidak dapat membagi dengan nol")
            r, label = 1 / v, f"1/({s})"
        elif kind == "sqr":
            r, label = v * v, f"sqr({s})"
        else:
            if v < 0:
                return self._fail("Input tidak valid")
            r, label = math.sqrt(v), f"√({s})"
        if not math.isfinite(r):
            return self._fail("Melebihi batas")
        self.cur, self.tail, self.new, self.just_op = fmt(r), label, True, False

    # memori
    def memory(self, k):
        if self.error:
            self.reset()
        if k == "MC":
            self.mem = None
        elif k == "MR" and self.mem is not None:
            self.cur, self.tail, self.new, self.just_op = fmt(self.mem), "", True, False
        elif k == "M+":
            self.mem, self.new = (self.mem or 0) + self.val, True
        elif k == "M−":
            self.mem, self.new = (self.mem or 0) - self.val, True
        elif k == "MS":
            self.mem, self.new = self.val, True


# ======================= GUI =======================
BG, NUM, FN, EQ = "#202020", "#3b3b3b", "#323232", "#3d8bfd"
HOVER = {NUM: "#4a4a4a", FN: "#414141", EQ: "#6aa6ff", BG: "#2d2d2d"}
KEYS = [("%", "CE", "C", "⌫"), ("1/x", "x²", "²√x", "÷"), ("7", "8", "9", "×"),
        ("4", "5", "6", "−"), ("1", "2", "3", "+"), ("+/−", "0", ",", "=")]


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Kalkulator Desktop")
        self.geometry("353x622")
        self.minsize(320, 560)
        self.configure(bg=BG)
        self.e = Engine()
        self.columnconfigure(0, weight=1)
        for r in range(4, 10):
            self.rowconfigure(r, weight=1)

        tk.Label(self, text="Standar", bg=BG, fg="white", font=("Segoe UI", 16, "bold"),
                 anchor="w").grid(row=0, column=0, sticky="ew", padx=14, pady=(14, 0))
        self.expr_lbl = tk.Label(self, anchor="e", bg=BG, fg="#9d9d9d", font=("Segoe UI", 11), padx=14)
        self.expr_lbl.grid(row=1, column=0, sticky="ew", pady=(8, 0))
        self.disp_lbl = tk.Label(self, anchor="e", bg=BG, fg="white", padx=14)
        self.disp_lbl.grid(row=2, column=0, sticky="ew", pady=(0, 6))

        mem = tk.Frame(self, bg=BG)
        mem.grid(row=3, column=0, sticky="ew", padx=2, pady=(4, 6))
        self.mem_btns = {}
        for i, k in enumerate(["MC", "MR", "M+", "M−", "MS"]):
            mem.columnconfigure(i, weight=1, uniform="m")
            b = self.button(mem, k, BG, "white", ("Segoe UI", 10), lambda k=k: self.mem_press(k))
            b.config(disabledforeground="#7a7a7a")
            b.grid(row=0, column=i, sticky="ew", padx=1)
            self.mem_btns[k] = b

        pad = tk.Frame(self, bg=BG)
        pad.grid(row=4, column=0, rowspan=6, sticky="nsew", padx=2, pady=(0, 2))
        for c in range(4):
            pad.columnconfigure(c, weight=1, uniform="c")
        for r, row in enumerate(KEYS):
            pad.rowconfigure(r, weight=1, uniform="r")
            for c, k in enumerate(row):
                digit = k.isdigit() or k == ","
                bg = EQ if k == "=" else NUM if digit else FN
                font = ("Segoe UI", 16, "bold") if digit or k in ("+/−", "=") else ("Segoe UI", 14)
                self.button(pad, k, bg, "white", font, lambda k=k: self.press(k)).grid(
                    row=r, column=c, sticky="nsew", padx=1, pady=1)

        self.bind("<Key>", self.on_key)
        for s, k in (("<Return>", "="), ("<KP_Enter>", "="), ("<BackSpace>", "⌫"),
                     ("<Escape>", "C"), ("<Delete>", "CE")):
            self.bind(s, lambda ev, k=k: self.press(k))
        self.refresh()

    @staticmethod
    def button(parent, text, bg, fg, font, cmd):
        b = tk.Button(parent, text=text, bd=0, relief="flat", bg=bg, fg=fg, font=font,
                      activebackground=HOVER[bg], activeforeground=fg, command=cmd, cursor="hand2")
        b.bind("<Enter>", lambda ev: b["state"] == "normal" and b.config(bg=HOVER[bg]))
        b.bind("<Leave>", lambda ev: b.config(bg=bg))
        return b

    def press(self, k):
        e = self.e
        if k.isdigit():
            e.digit(k)
        elif k == ",":
            e.decimal()
        elif k in "+−×÷":
            e.operator(k)
        elif k == "=":
            e.equals()
        elif k == "CE":
            e.ce()
        elif k == "C":
            e.reset()
        elif k == "⌫":
            e.back()
        elif k == "+/−":
            e.negate()
        elif k == "%":
            e.percent()
        else:
            e.unary({"1/x": "recip", "x²": "sqr", "²√x": "sqrt"}[k])
        self.refresh()

    def mem_press(self, k):
        self.e.memory(k)
        self.refresh()

    def on_key(self, ev):
        k = {"-": "−", "*": "×", "/": "÷", ".": ","}.get(ev.char, ev.char)
        if ev.char and (k.isdigit() or k in ",+−×÷%="):
            self.press(k)

    def refresh(self):
        e = self.e
        text = e.error or disp(e.cur)
        n = len(text)
        size = 16 if e.error else 44 if n <= 10 else max(18, 44 - (n - 10) * 3)
        self.disp_lbl.config(text=text, font=("Segoe UI", size, "bold"))
        self.expr_lbl.config(text=disp_expr(e.top)[-38:])
        for k in ("MC", "MR"):
            self.mem_btns[k].config(state="normal" if e.mem is not None else "disabled",
                                    bg=BG)


if __name__ == "__main__":
    App().mainloop()
